! command -v rainbow-wal && exit 1;
rainbow-wal --filename "$1";
kill -SIGUSR1 "$(pgrep kitty)" > /dev/null 2>&1;
